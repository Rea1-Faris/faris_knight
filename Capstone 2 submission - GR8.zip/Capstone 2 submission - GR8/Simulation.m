L(1) = Link([0 9.8 0 0]);
L(2) = Link([0 0 24 0 1]);
L(3) = Link([0 -3 12 0]);
L(4) = Link([0 -11.5 0 0]);
R = SerialLink(L, 'qlim', [-pi/4 pi/4;0 30;-pi/4 pi/4; -2*pi 2*pi])
plot(R, [0 0 0 0], 'workspace', [-80 80 -80 80 -80 80], 'jvec')
teach(R)